#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct valores{
 int numero;
 int posicao;
} valores;

void saida(int n, valores v[]){
	for(int i = 0; i < n; i++){
			int menor = 0;
			for(int j = i; j >= 0; j--){
				if((v[i].numero > v[j].numero)){
					menor = v[j].posicao;
					break;
				}
			}
			printf("%d ", menor);
	}
}

void leitura(int n, valores v[]){
	for(int i = 0; i < n; i++){
				scanf("%d", &v[i].numero);
				v[i].posicao = i+1;
	}
}

int main (){
	int n;
	scanf("%d", &n);
	valores v[n];
	leitura(n, v);
	saida(n, v);
	return 0;
}


