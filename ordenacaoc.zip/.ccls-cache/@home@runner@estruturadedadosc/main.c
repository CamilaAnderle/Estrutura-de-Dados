//ordenando palavras 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct Palavras{
	char palavra[11];
	int tamanho;
} Palavras;

void ler_palavras(int n, Palavras plv[]){
	int tamanho_palavra;
	for(int i = 0; i < n; i++){
		scanf("%s", plv[i].palavra);
	}
	for(int j = 0; j < n; j++){
		tamanho_palavra = strlen(plv[j].palavra);
		plv[j].tamanho = tamanho_palavra;
	}
}

static void merge(Palavras *plv, Palavras *v1, Palavras *v2, int n) {

    int n_v1 = n / 2;
    int n_v2 = n - n_v1;
    int i = 0;
    int j = 0;
    int k = 0;

    /** Enquanto não chegar ao fim da primeira
     *  e da segunda metade **/
    for (i = 0; j < n_v1 && k < n_v2; i++) {
        /* Se o elemento da primeira metade
         * é menor ou igual ao da segunda metade,
         * insira-o no vetor resultado
         */
        if (v1[j].tamanho <= v2[k].tamanho) {
            plv[i] = v1[j++];
        }
        /* Caso contrário, insira o elemento da
         * segunda metade no vetor resultado */
        else {
            plv[i] = v2[k++];
        }
    }

    /** Se ainda  restam elementos na primeira partição **/
    while (j < n_v1) {
        /* Copiamos os elementos para o vetor resultado */
        plv[i++] = v1[j++];
    }
    /** Se ainda  restam elementos na segunda partição **/
    while (k < n_v2) {
        /* Copiamos os elementos para o vetor resultado */
        plv[i++] = v2[k++];
    }
}

void merge_sort(Palavras *plv, int n) {
    size_t mid;
    if (n > 1) {
        mid = n / 2;
        /* aloca espaço para os subvetores */
        Palavras *v1 = malloc(sizeof(Palavras) * mid);
        Palavras *v2 = malloc(sizeof(Palavras) * (n - mid));
        /* Copia os elementos de v para os subvetores */
        int i;
        for (i = 0; i < mid; i++) {
            v1[i] = plv[i];
        }
        for (i = mid; i < n; i++) {
            v2[i - mid] = plv[i];
        }
        /* Ordena recursivamente a primeira metade */
        merge_sort(v1, mid);
        /* Ordena recursivamente a segunda metade */
        merge_sort(v2, n - mid);
        /* Faz a junção das duas metades */
        merge(plv, v1, v2, n);
        /* Libera o espaço alocado */
        free(v1);
        free(v2);
    }
}

void imprimir(Palavras plv[], int n){
	for(int i = 0; i < n; i++){
			printf("%s\n", plv[i].palavra);
	}
}

int main(void) {
	int n;
	scanf("%d", &n);
	Palavras plv[n];
	ler_palavras(n, plv);
	int posicaoInicio = 0, posicaoFim = n-1;
	merge_sort(plv, n);
	imprimir(plv, n);
  return 0;
}
