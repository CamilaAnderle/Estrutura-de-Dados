#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct autores{
  char sobrenome[32];
  int indiceH;
} autores;

static void heapify(int *v, size_t i, size_t size) {
 int left;
 int right;
 int largest;
 while (i < size) {
 left = (i * 2) + 1;
 right = (i * 2) + 2;
 largest = i;
 if (left < size && v[left] > v[largest]) {
 largest = left;
 }
 if (right < size && v[right] > v[largest]) {
 largest = right;
 }
 if (i == largest) {
 break;
 }
 int swp = v[i];
	v[i] = v[largest];
 v[largest] = swp;
 i = largest;
 }
}

static void make_heap(int *v, size_t size) {
 int i;
 for (i = size / 2; i >= 0; i--) {
 heapify(v, i, size);
 }
 }

 void heap_sort(int *v, size_t size){
 make_heap(v, size);
 for (int i = size - 1; i > 0; i--) {
int swp = v[i];
 v[i] = v[0];
	 v[0] = swp;
 heapify(v, 0, i);
 }
 }

int calculaIndiceH(int numCitacao[], int numPublicacao){
  for(int i = 0, j = numPublicacao; i < numPublicacao; i++, j--){
    if(numCitacao[i] >= j)
      return j;
  }
  return 0;
}

static void heapify_autor(autores *v, size_t i, size_t size) {
 int left;
 int right;
 int largest;
 while (i < size) {
 left = (i * 2) + 1;
 right = (i * 2) + 2;
 largest = i;
 if (left < size && v[left].indiceH > v[largest].indiceH || (v[left].indiceH == v[largest].indiceH && strcmp(v[left].sobrenome, v[largest].sobrenome) == -1)) {
 largest = left;
 }
 if (right < size && v[right].indiceH > v[largest].indiceH || (v[right].indiceH == v[largest].indiceH && strcmp(v[right].sobrenome, v[largest].sobrenome) == -1)) {
 largest = right;
 }
 if (i == largest) {
 break;
 }
 int swp = v[i].indiceH;
	v[i].indiceH = v[largest].indiceH;
 v[largest].indiceH = swp;

char swpSobre[32];
   strcpy(swpSobre, v[i].sobrenome);
    strcpy(v[i].sobrenome, v[largest].sobrenome);
    strcpy( v[largest].sobrenome, swpSobre);
 i = largest;
 }
}

static void make_heap_autor(autores *v, size_t size) {
 int i;
 for (i = size / 2; i >= 0; i--) {
 heapify_autor(v, i, size);
 }
 }

 void heap_sort_autor(autores *v, size_t size){
 make_heap_autor(v, size);
 for (int i = size - 1; i > 0; i--) {

    int swp = v[i].indiceH;
	v[i].indiceH = v[0].indiceH;
 v[0].indiceH = swp;

char swpSobre[32];
   strcpy(swpSobre, v[i].sobrenome);
    strcpy(v[i].sobrenome, v[0].sobrenome);
    strcpy( v[0].sobrenome, swpSobre);
   
 heapify_autor(v, 0, i);
 }
 }


int main(){
  int n;
  scanf("%d", &n);

  autores autor[1000];
  for(int i = 0; i < n; i++){
    int numPublicacao;
    scanf("%s %d", autor[i].sobrenome, &numPublicacao);

    int numCitacao[numPublicacao];
    
    for(int j = 0; j < numPublicacao; j++){
      scanf("%d", &numCitacao[j]);
    }

    heap_sort(numCitacao, numPublicacao);
    autor[i].indiceH = calculaIndiceH(numCitacao, numPublicacao);
    
  }
  heap_sort_autor(autor, n);

  for(int i = n-1; i >= 0; i--){
    printf("%s %d\n", autor[i].sobrenome, autor[i].indiceH);
  }
  
  return 0;
}