#include <stdio.h>
#include <stdlib.h>

typedef struct Pilotos{
	char nome[31];
	int segundos1;

	int mls1;
	int segundos2;
	int mls2;
	int segundos3;
	int mls3;
	int tempoTotal;
}Pilotos;

void leitura(Pilotos pilotos[], int n){
		for(int i = 0; i < n; i++){
		scanf("%s", pilotos[i].nome);
		scanf("%d.%d %d.%d %d.%d", &pilotos[i].segundos1,  &pilotos[i].mls1, &pilotos[i].segundos2, &pilotos[i].mls2, &pilotos[i].segundos3, &pilotos[i].mls3 );
	}
}

void converter_mls(Pilotos pilotos[], int n){
	for(int i = 0; i < n; i++){
		pilotos[i].mls1 += pilotos[i].segundos1 * 1000;
		pilotos[i].mls2 += pilotos[i].segundos2 * 1000;
		pilotos[i].mls3 += pilotos[i].segundos3 * 1000;
		pilotos[i].tempoTotal = pilotos[i].mls1 + pilotos[i].mls2 + pilotos[i].mls3;
	}
}

static void merge(Pilotos *pilotos, Pilotos *v1, Pilotos *v2, int n) {
    int n_v1 = n / 2;
    int n_v2 = n - n_v1;
    int i = 0;
    int j = 0;
    int k = 0;
    for (i = 0; j < n_v1 && k < n_v2; i++) {
        if (v1[j].tempoTotal <= v2[k].tempoTotal) {
            pilotos[i] = v1[j++];
        }
        else {
            pilotos[i] = v2[k++];
        }
    }
    while (j < n_v1) {
        pilotos[i++] = v1[j++];
    }
    while (k < n_v2) {
        pilotos[i++] = v2[k++];
    }
}
 
void merge_sort(Pilotos *pilotos, int n) {
    size_t mid;
    if (n > 1) {
        mid = n / 2;
        Pilotos *v1 = malloc(sizeof(Pilotos) * mid);
        Pilotos *v2 = malloc(sizeof(Pilotos) * (n - mid));
        int i;
        for (i = 0; i < mid; i++) {
            v1[i] = pilotos[i];
        }
        for (i = mid; i < n; i++) {
            v2[i - mid] = pilotos[i];
        }
        merge_sort(v1, mid);
        merge_sort(v2, n - mid);
        merge(pilotos, v1, v2, n);
        free(v1);
        free(v2);
    }
}


void converter_segundos(Pilotos *pilotos, int n){
	for(int i = 0; i < n; i++){
 		pilotos[i].segundos1 = pilotos[i].tempoTotal/60000;
		pilotos[i].mls1 = (pilotos[i].tempoTotal % 60000) / 1000;
		pilotos[i].mls2 = (pilotos[i].tempoTotal % 1000);
	}
}

void imprimir(Pilotos *pilotos, int n){
	for(int i = 0; i < n; i++){
		printf("%d. %s - %d:%02d.%03d\n", i+1, pilotos[i].nome, pilotos[i].segundos1, pilotos[i].mls1, pilotos[i].mls2);
	}
}

int main(){
	int n;
	scanf("%d", &n);
	Pilotos pilotos[20];
	leitura(pilotos, n);
	converter_mls(pilotos, n);
	merge_sort(pilotos, n);
	converter_segundos(pilotos, n);
	imprimir(pilotos, n);
	return 0;
}