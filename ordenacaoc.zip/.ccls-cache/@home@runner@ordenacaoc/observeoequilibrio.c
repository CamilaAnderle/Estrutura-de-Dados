#include <stdio.h>
#include <stdlib.h>
 
void entrada(int n, int v[]){
	for(int i = 0; i < n; i++){
		scanf("%d", &v[i]);
		if(v[i] < 0) v[i] = v[i]*(-1);
	}
}
 
static void heapify(int *v, size_t i, size_t size) {
    int left;
    int right;
    int largest;
    while (i < size) {
        left = (i * 2) + 1;
        right = (i * 2) + 2;
        largest = i;
        if (left < size && v[left] > v[largest]) {
            largest = left;
        }
        if (right < size && v[right] > v[largest]) {
            largest = right;
        }
        if (i == largest) {
            break;
        }
        int swp = v[i];
        v[i] = v[largest];
        v[largest] = swp;
        i = largest;
    }
}
 
void make_heap(int *v, size_t size) {
    for (int i = size / 2; i >= 0; i--) {
        heapify(v, i, size);
    }
}
 
void heap_sort(int *v, size_t size) {
    int i;
    make_heap(v, size);
    for (i = size - 1; i > 0; i--) {
        int swp = v[i];
        v[i] = v[0];
        v[0] = swp;
        heapify(v, 0, i);
    }
}
 
int testarEquilibrada(int n, int v[]){
	int controle;
	for(int i = 0; i < n; i++){
		if(v[i] != 0 && (v[i+1]%v[i]) == 0) controle = 0;
		else if(v[i] == 0) controle = 0;
		else return controle = 1;
	} return controle;
}	
 
void impressao(int n, int v[]){
	if(testarEquilibrada(n, v) == 0){
		printf("Sim");
	} else printf("Nao");
}

int main(){
	int n;
	scanf("%d", &n);
	int v[200000];
	entrada(n, v);
	size_t size = n;
	heap_sort(v, size);
	impressao(n, v);
	return 0;
}