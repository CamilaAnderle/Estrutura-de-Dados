//ordenando palavras 
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


typedef struct Palavras{
	char palavra[11];
	int tamanho;
} Palavras;

void ler_palavras(int n, Palavras plv[]){
	for(int i = 0; i < n; i++){
		scanf("%s", plv[i].palavra);
		plv[i].tamanho = strlen(plv[i].palavra);
	}
}

void merge(Palavras *plv, Palavras *v1, Palavras *v2, int n) {
    int n_v1 = n / 2;
    int n_v2 = n - n_v1;
    int i = 0;
    int j = 0;
    int k = 0;
    for (i = 0; j < n_v1 && k < n_v2; i++) {
        if (v1[j].tamanho <= v2[k].tamanho) {
            plv[i] = v1[j++];
        }
        else {
            plv[i] = v2[k++];
        }
    }
    while (j < n_v1) {
        plv[i++] = v1[j++];
    }
    while (k < n_v2) {
        plv[i++] = v2[k++];
    }
}

void merge_sort(Palavras *plv, int n) {
    size_t mid;
    if (n > 1) {
        mid = n / 2;
        Palavras *v1 = malloc(sizeof(Palavras) * mid);
        Palavras *v2 = malloc(sizeof(Palavras) * (n - mid));
        int i;
        for (i = 0; i < mid; i++) {
            v1[i] = plv[i];
        }
        for (i = mid; i < n; i++) {
            v2[i - mid] = plv[i];
        }
        merge_sort(v1, mid);
        merge_sort(v2, n - mid);
        merge(plv, v1, v2, n);
        free(v1);
        free(v2);
    }
}

void imprimir(Palavras plv[], int n){
	for(int i = 0; i < n; i++){
			printf("%s\n", plv[i].palavra);
	}
}

int main(void) {
	int n;
	scanf("%d", &n);
	Palavras plv[n];
	ler_palavras(n, plv);
	merge_sort(plv, n);
	imprimir(plv, n);
  return 0;
}
