#include <stdio.h>
#include <stdlib.h>

void leitura(unsigned long long int peso_chocolate[], int n) {
  for (int k = 0; k < n; k++) {
    scanf("%lld", &peso_chocolate[k]);
  }
}

void Fibonacci(unsigned long long int vetorFibonacci[]) {
  vetorFibonacci[0] = 1;
  vetorFibonacci[1] = 1;
  for (int m = 2; m < 100; m++) {
    vetorFibonacci[m] = vetorFibonacci[m - 1] + vetorFibonacci[m - 2];
  }
}

int buscar(unsigned long long int vetorFibonacci[],
           unsigned long long int peso_chocolate, int tam) {
  int inicio = 0;
  int fim = tam - 1;
  int meio;
  while (inicio <= fim) {
    meio = (inicio + fim) / 2;
    if (vetorFibonacci[meio] == peso_chocolate) {
      return meio;
    } else if (vetorFibonacci[meio] < peso_chocolate) {
      inicio = meio + 1;
    } else {
      fim = meio - 1;
    }
  }
  return fim;
}

int subtrair(unsigned long long int vetorFibonacci[],
             unsigned long long int peso_chocolate[], int n, int i, int tam) {
  int iteracao = 0;
  while (peso_chocolate[i] != 0) {
    peso_chocolate[i] = peso_chocolate[i] - vetorFibonacci[buscar(vetorFibonacci, peso_chocolate[i], tam)];
    iteracao++;
  }
  return iteracao;
}

void saida(unsigned long long int vetorFibonacci[],
           unsigned long long int peso_chocolate[], int n, int tam) {
  for (int i = 0; i < n; i++) {
    printf("%d\n", subtrair(vetorFibonacci, peso_chocolate, n, i, tam));
  }
}

int main() {
  int n;
  scanf("%d", &n);
  unsigned long long int peso_chocolate[100000];
  leitura(peso_chocolate, n);
  unsigned long long int vetorFibonacci[100];
  Fibonacci(vetorFibonacci);
  saida(vetorFibonacci, peso_chocolate, n, 100);
  return 0;
}