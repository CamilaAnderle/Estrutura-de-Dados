#include <stdio.h>
#include <stdlib.h>

typedef struct vet{
    int numeros;
    int posicao;
} vet;

int busca_binaria(vet *v, int teste, int i, int n) {
    int inicio = i+1;
    int fim = n - 1;
    while (inicio <= fim) {
    int meio = inicio + (fim - inicio) / 2;
    if (v[meio].numeros == teste ) return meio; 
		else if (v[meio].numeros < teste ) {
    inicio = meio + 1;
    } else {
    fim = meio - 1;
    }
 }
 return -1;
}

int busca_iguais_esquerda(vet *v, int teste, int i, int n){
	int auxiliar = busca_binaria(v,teste, i, n);
	int j = auxiliar;
	if(auxiliar != -1){
		while((v[auxiliar].numeros == v[j].numeros) && (j>i)){
			j--;
		}
		return j+1;
	}
	return -1;
}

int busca(int n, int c, vet *v){
    for(int i = 0; i < n; i++){
        int teste = c - v[i].numeros;
        int buscabinaria = busca_iguais_esquerda(v,teste, i, n);
        if(buscabinaria != -1){
					if(v[i].posicao != v[buscabinaria].posicao){
            printf("%d %d\n", v[i].posicao+1, v[buscabinaria].posicao+1);
            return 0;
					}
					else if (v[buscabinaria + 1].numeros == v[buscabinaria].numeros){
						 printf("%d %d\n", v[i].posicao+1, v[buscabinaria+1].posicao+1);
					}
					else if(v[buscabinaria -1].numeros == v[buscabinaria].numeros){
						 printf("%d %d\n", v[i].posicao+1, v[buscabinaria+1].posicao+1);
					}
				}
    } 
    printf("-1\n");
    return 0;
}

static void merge(vet *v, vet *v1, vet *v2, size_t size) {
    size_t size_v1 = size / 2;
    size_t size_v2 = size - size_v1;
    size_t i = 0;
    size_t j = 0;
    size_t k = 0;
	
    for (i = 0; j < size_v1 && k < size_v2; i++) {
        if (v1[j].numeros <= v2[k].numeros) {
            v[i] = v1[j++];
        }
        else {
            v[i] = v2[k++];
        }
    }
    while (j < size_v1) {
        v[i++] = v1[j++];
    }
    while (k < size_v2) {
        v[i++] = v2[k++];
    }
}

void merge_sort(vet *v, size_t size) {
    size_t mid;
    if (size > 1) {
        mid = size / 2;
        vet *v1 = malloc(sizeof(int) * mid * 10);
        vet *v2 = malloc(sizeof(int) * (size - mid)*10);
        int i;
        for (i = 0; i < mid; i++) {
            v1[i] = v[i];
        }
        for (i = mid; i < size; i++) {
            v2[i - mid] = v[i];
        }
        merge_sort(v1, mid);
        merge_sort(v2, size - mid);
        merge(v, v1, v2, size);
        free(v1);
        free(v2);
    }
}


int main(void){
    int n, c;
    scanf("%d %d", &n, &c);
	  vet v[n];
	for(int i = 0; i < n; i++){
        scanf("%d", &v[i].numeros);
        v[i].posicao = i;
    }
    
    size_t size = n;
    merge_sort(v, size);
    busca(n, c, v);
    return 0;
}