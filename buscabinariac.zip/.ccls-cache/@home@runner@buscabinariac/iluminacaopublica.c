#include <stdio.h>

int testa_n_postes(int n_casas, int *casas, int n_postes, int *postes,
									 int meio) {
	int teste = 0;
	int i = 0, j = 0;
	while (i < n_postes && j < n_casas) {
		int r_x = postes[i] + meio;
		int r_menos_x = postes[i] - meio;
		if (casas[j] >= r_menos_x && casas[j] <= r_x) {
			j++;
		} else {
			i++;
		}
	}
	return !(j < n_casas);
}

int busca_binaria_resposta(int n_casas, int *casas, int n_postes, int *postes) {
	int maximo = 1000000000;
	int minimo = 0;
	int minimo_postes;
	while (minimo <= maximo) {
		int meio = minimo + (maximo - minimo)/ 2;
		if (testa_n_postes(n_casas, casas, n_postes, postes, meio) == 1)
			minimo_postes = meio, maximo = meio - 1;
		else
			minimo = meio + 1;
	}
	return minimo_postes;
}

int main(void) {

	int n_casas;
	scanf("%d", &n_casas);
	int casas[n_casas];
	for (int i = 0; i < n_casas; i++) {
		scanf("%d", &casas[i]);
	}
	int n_postes;
	scanf("%d", &n_postes);
	int postes[n_postes];
	for (int j = 0; j < n_postes; j++) {
		scanf("%d", &postes[j]);
	}

	printf("%d", busca_binaria_resposta(n_casas, casas, n_postes, postes));

	return 0;
}