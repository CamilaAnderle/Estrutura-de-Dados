#include <stdio.h>
#include <stdlib.h>


int busca_fim(int inicio, int fim, int vetN[], int k){
	int res = -1;
    while(inicio <= fim){
		int meio = inicio + (fim - inicio)/2;
		if(k< vetN[meio]){
            fim = meio-1;
        }
        else if(k>vetN[meio]) {
            inicio = meio+1;
        }
        else{
            res = meio;
            inicio =  meio+1;
        }
	}
    return res;
}

int busca_inicio(int inicio, int fim, int vetN[], int k){
	int res = -1;
    while(inicio <= fim){
		int meio = inicio + (fim - inicio)/2;
		if(k< vetN[meio]){
            fim = meio-1;
        }
        else if(k>vetN[meio]) {
            inicio = meio+1;
        }
        else{
            res = meio;
            fim =  meio-1;
        }
	}
    return res;
}

void saida(int n, int q, int vetN[], int vetQ[]){
	for(int i = 0; i < q; i++){
		int inicio = busca_inicio(0, n-1, vetN, vetQ[i]);
		int fim= busca_fim(0, n-1, vetN, vetQ[i]);
		if(inicio != -1) printf("%d %d\n", inicio+1, fim+1);
		else printf("%d\n", -1);
	}
}

static void merge(int *vetN, int *v1, int *v2, size_t size) {
    size_t size_v1 = size / 2;
    size_t size_v2 = size - size_v1;
    size_t i = 0;
    size_t j = 0;
    size_t k = 0;

    for (i = 0; j < size_v1 && k < size_v2; i++) {
        if (v1[j] <= v2[k]) {
            vetN[i] = v1[j++];
        }
        else {
            vetN[i] = v2[k++];
        }
    }
    while (j < size_v1) {
        vetN[i++] = v1[j++];
    }
    while (k < size_v2) {
        vetN[i++] = v2[k++];
    }
}

void merge_sort(int *vetN, size_t size) {
    size_t mid;
    if (size > 1) {
        mid = size / 2;
        int *v1 = malloc(sizeof(int) * mid);
        int *v2 = malloc(sizeof(int) * size - mid);
        int i;
        for (i = 0; i < mid; i++) {
            v1[i] = vetN[i];
        }
        for (i = mid; i < size; i++) {
            v2[i - mid] = vetN[i];
        }
        merge_sort(v1, mid);
        merge_sort(v2, size - mid);
        merge(vetN, v1, v2, size);
        free(v1);
        free(v2);
    }
}
	
void leitura(int n, int q, int vetN[], int vetQ[]){
	for(int i = 0; i < n; i++){
		scanf("%d", &vetN[i]);
	}
	for(int j = 0; j < q; j++){
		scanf("%d", &vetQ[j]);
	}
}

int main(void) {
    int n, q;
	scanf("%d %d", &n, &q);
	int vetN[n];
	int vetQ[q];
	leitura(n, q, vetN, vetQ);
	size_t size = n;
	merge_sort(vetN, size);
	saida(n, q, vetN, vetQ);
  return 0;
}