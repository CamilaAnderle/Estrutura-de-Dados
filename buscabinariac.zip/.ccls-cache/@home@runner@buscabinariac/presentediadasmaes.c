#include <stdio.h>
#include <stdlib.h>

void busca_binaria_resposta(int caixasDeChocolate, int chocolatesPorCaixa[], int maes){
	int totalDeChocolates = 0;
	totalDeChocolates = 1000000000;
	int limiteInferior = 0;
	int limiteSuperior = totalDeChocolates;
	int resposta = 0;
	while(limiteInferior <= limiteSuperior){
		int meio = limiteInferior + (limiteSuperior-limiteInferior)/2;
		int auxiliar = 0;
		if(meio != 0){
			for(int j = 0; j < caixasDeChocolate; j++){
				auxiliar += chocolatesPorCaixa[j]/meio;
			}
		}	
		if(auxiliar >= maes || meio == 0){
			resposta = meio;
			limiteInferior = meio + 1;
		}
		else{
			limiteSuperior = meio - 1;
		}
	}
	printf("%d\n", resposta);
}



void leitura(int caixasDeChocolate, int chocolatesPorCaixa[]){
	for(int i = 0; i < caixasDeChocolate; i++){
		scanf("%d", &chocolatesPorCaixa[i]);
	}
}
int main(){
	int caixasDeChocolate, maes;
	scanf("%d %d", &caixasDeChocolate, &maes);
	int chocolatesPorCaixa[caixasDeChocolate];
	leitura(caixasDeChocolate, chocolatesPorCaixa);

	busca_binaria_resposta(caixasDeChocolate, chocolatesPorCaixa, maes);
	return 0;
}

